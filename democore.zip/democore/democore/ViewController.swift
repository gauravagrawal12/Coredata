//
//  ViewController.swift
//  democore
//
//  Created by Mac on 14/12/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController, DataPass {

    @IBAction func show(_ sender: UIButton) {
        let next = storyboard?.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        next.delegate = self
        navigationController?.pushViewController(next, animated: true)
    }
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var txtcity: UITextField!
    @IBOutlet weak var txtmbile: UITextField!
    var i = Int()
    var isUpdate = Bool()
    @IBAction func Save(_ sender: UIButton) {
        let dict = ["name":txtname.text,"address":txtaddress.text,"city":txtcity.text,"mobile":txtmbile.text]
        if isUpdate{
            DatabaseHelper.shareInstance.editData(object: dict as! [String:String], i: i)
        }else {
          DatabaseHelper.shareInstance.save(object: dict as! [String : String])
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func data(object: [String : String], index:Int, isEdit: Bool) {
        txtname.text = object["name"]
        txtaddress.text = object["address"]
        txtcity.text = object["city"]
        txtmbile.text = object["mobile"]
        i = index
        isUpdate = isEdit
    }
}

