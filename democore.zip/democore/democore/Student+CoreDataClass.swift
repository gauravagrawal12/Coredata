//
//  Student+CoreDataClass.swift
//  democore
//
//  Created by Mac on 14/12/19.
//  Copyright © 2019 Mac. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
